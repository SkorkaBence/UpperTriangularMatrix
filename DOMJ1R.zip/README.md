# Felsőháromszög mátrix (OAF 1. beadandó)
## Feladat
Valósítsa meg az egész számokat tartalmazó felsőháromszög mátrixtípust (a mátrixok a főátlójuk alatt csak nullát tartalmaznak)! Ilyenkor elegendő csak a főátló és afeletti elemeket reprezentálni egy sorozatban, amelyet egy dinamikus helyfoglalású tömbben helyezzünk el. Implementálja önálló metódusként a mátrix iedik sorának j-edik elemét visszaadó műveletet, valamint hatékony összeadás és szorzás műveleteket, továbbá a mátrix (négyzetes alakú) kiírását, és végül a másoló konstruktort és az értékadás operátort! 
